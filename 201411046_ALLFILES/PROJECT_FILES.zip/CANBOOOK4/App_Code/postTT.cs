﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for postTT
/// </summary>
public class postTT
{
    public int ttPoint { get; set; }
    public int  postId { get; set; }
    public postTT()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}