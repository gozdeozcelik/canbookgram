﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Catagory
/// </summary>
public class Catagory
{
    public int PersonId { get; set; }
    public string FirstName { get; set; }
    public Catagory()
    {
        //
        // TODO: Add constructor logic here
        //
    }
}